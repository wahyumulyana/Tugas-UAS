<!DOCTYPE html>
<html lang="en" dir=ltr"">
<head>
	<meta charset="utf-8">
	<!-- Berikut adalah pemanggilan file.css -->
	<link rel="stylesheet" type="text/css" href="style.css" />
	<title>MENU ADMIN</title>
</head>
<body>
	<!-- Ini adalah container -->
	<div id="container">
		<!-- Membuat Header-->
			<header>
				<h1>Halaman Admin </h1>
			</header>
		<!-- Membuat Navigasi-->
			<nav>
				<ul>
					<li class="active"><a href="index.php" title="Home"> Home </a></li>
					
					<li><a href="logout.php" title="About">Logout</a></li>
				</ul>
			</nav>