<!-- Membuat sidebar -->
		<div class="sidebar">
			<div class="widget-box">
				<h3 class="title"> Menu</h3>
			<ul>

				<li><a href="form_barang.php"> Tambah Barang</a></li>
				<li><a href="barang.php"> List Barang</a></li>
				<li><a href="form_kategori.php"> Tambah Kategori</a></li>
				<li><a href="kategori.php"> List Kategori</a></li>
				
			</ul>
		</div>

			<div class="widget-box">
				
			</div>
		</div>