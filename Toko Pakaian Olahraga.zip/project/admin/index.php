<?php 
include_once 'barang.php';