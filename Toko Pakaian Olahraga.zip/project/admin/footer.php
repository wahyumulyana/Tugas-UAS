<!-- Membuat footer -->
		<footer align="center">
			<p>  copyright &copy;2018 </p>
		</footer>