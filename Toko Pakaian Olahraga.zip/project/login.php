<?php
	session_start();
	if(isset($_SESSION['nama'])){
		header("location:admin/barang.php");
	}else{

$title="Login";
$error=null;
include_once 'admin/koneksi.php';

if(isset($_POST['submit'])) {
	$user = $_POST['nama'];
	$password = $_POST ['password'];
	$sql = "SELECT * FROM login WHERE nama= '{$user}' AND password='{$password}'";
	$result = mysqli_query($conn, $sql);
	if ($result && $result->num_rows > 0) {
		session_start();
		$_SESSION['isLogin'] = 1;
		header('location: admin/index.php');
	} else
		$error = "username atau password salah.";
}

include_once 'header.php'; 
?>
<div id="login">
	<h2>Login Form</h2>
	<form action="" method="post">
		<label>Username :</label>
		<input id="name" name="nama" placeholder="username" type="text">
		<label>password :</label>
		<input id="password" name="password" placeholder="*********" type="password">
		<input name="submit" type="submit" value="Login">
		<span><?php echo $error; ?></span>
	</form>
</div>
	<?php include_once 'admin/footer.php'; }?>