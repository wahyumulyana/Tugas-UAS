<?php
include_once 'header.php';
?>
<!DOCTYPE html>
<html>
<div class="daftar">
	<div class="main">
<body>
<header>
<h1>Profil</h1>
</header>


<form action="#" style="width: 505px"class="posisi";>
<fieldset class="h"/>
<table style="width: 500px;">
<tr>
<td><b>Nama Lengkap</b></td>
<td>:</td>
<td>Wahyu Mulyana</td>
</tr>
<tr>
<td><b>Nama Panggilan</b></td>
<td>:</td>
<td>Wahyu</td>
</tr>
<tr>
<td><b>Tempat, Tanggal Lahir</b></td>
<td>:</td>
<td>Bogor, 01 Juli 1998</td>
</tr>
<tr>
<td><b>Umur</b></td>
<td>:</td>
<td>20 Tahun</td>
</tr>
<tr>
<td><b>Jenis Kelamin</b></td>
<td>:</td>
<td>Laki - Laki</td>
</tr>
<tr>
<td><b>Agama</b></td>
<td>:</td>
<td>Islam</td>
</tr>
<tr>
<td><b>Alamat</b></td>
<td>:</td>
<td>Perum Mutiara Bekasi Jaya</td>
</tr>
<tr>
<td><b>Status</b></td>
<td>:</td>
<td>Belum Menikah</td>
</tr>
<tr>
<td><b>Pekerjaan</b></td>
<td>:</td>
<td>Mahasiswa</td>
</tr>
<tr>
<td><b>Kewarganegaraan</b></td>
<td>:</td>
<td>Indonesia</td>
</tr>
</table>
</fieldset>
</form>
</body>
</div>
</div>
</html>
<?php
include_once 'admin/footer.php';
?>