<?php 

include_once'admin/koneksi.php';
include_once 'header.php';

 ?>

 <?php 
include_once('admin/content.php');
include_once('sidebar.php');


  ?>

  <?php include_once'admin/footer.php';?>
  