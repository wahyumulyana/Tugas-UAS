<?php
include_once 'header.php';
include_once 'sidebar.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>contact</title>
	<!-- Google Fonts -->

<link href=".css" type="text/css" rel="stylesheet" />
</head>
<div class="content_a">
	<div class="daftar">
	<div class="main">
<body>
	<div>
		<header>
			<h1>Informasi Contact</h1>
		</header>
		
	</div>

<div>
	
</div><br>
<tr>
 <td><b>Kontak</b></td>
 </tr>
<table border="0">
	
 <tr>
 <td>Nama</td>
 <td>:</td>
 <td>Wahyu Mulyana</td>
 </tr>
 <tr>
 <td>Nomor Telepon</td>
 <td>:</td>
 <td>089623105890</td>
 </tr>
 <tr>
 <td>E-mail</td>
 <td>:</td>
 <td><a href="https://www.google.com/gmail/">wmulyana@mhs.pelitabangsa.ac.id</a></td>
 </tr>
 <tr>
 <td>web</td>
 <td>:</td>
 <td><a href="mulyana.my.id">Mulyana.my.id</a></td>

 </tr>
 <tr>
 	<td>alamat</td>
 	<td>:</td>
 	<td>Jl. Raya serang cibarusah no 34 </td>
 </tr>

</table>

</body>
</div>
</div>
</div>

</html
<?php
include_once 'admin/footer.php';
