<!-- Membuat sidebar -->
		
		
			<div class="sidebar">
			<div class="widget-box">
				<h3 class="title"> Menu</h3>
			<ul>
				<li><a href="index.php"> Semua Kategori</a></li> 
				<li><a href="content_baju.php"> Kategori Baju</a></li>
				<li><a href="content_celana.php"> Kategori Celana</a></li>
				<li><a href="content_jaket.php"> Kategori Jaket</a></li>
				<li><a href="content_sepatu.php"> Kategori Sepatu</a></li>
				
			</ul>
		</div>

			<div class="widget-box">
				<h3 class="title"> About</h3>
				<tr>
				<td>   </td><table>
				<td>Toko Pakaian Olahraga adalah sebuah toko yang bergerak di bidang retail. Toko ini memulai penjualannya di tahun 2018</td>

				</table></tr>			
			</div>
		</div>