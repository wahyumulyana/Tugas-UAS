<?php
include_once 'admin/koneksi.php';
error_reporting(E_ALL);
if ( isset($_POST['submit'])) {
	$id = $_POST['id'];
	$nama = $_POST['nama'];
	$pass = $_POST['password'];
	$sql ='INSERT INTO login (id, nama, password)';
	$sql .="VALUE ('{$id}', '{$nama}', '{$pass}')";
	$result = mysqli_query($conn, $sql);
		if (!$result) {
			die(mysqli_error($conn));
		}
		header('location: login.php');
}

include 'header.php';

	?>

<div id="login">
	<h2>Daftar Form</h2>
	<form action="" method="post">
		<label>ID :</label>
		<input id="id" name="id" placeholder="ID" type="text">
		<label>Username :</label>
		<input id="name" name="nama" placeholder="username" type="text">
		<label>password :</label>
		<input id="password" name="password" placeholder="*********" type="password">
		<input name="submit" type="submit" value="Daftar">
		
	</form>
</div>
<?php
include('admin/footer.php');
?>