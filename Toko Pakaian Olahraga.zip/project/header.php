<!DOCTYPE html>
<html lang="en" dir=ltr"">
<head>
	<meta charset="utf-8">
	<!-- Berikut adalah pemanggilan file.css -->
	<link rel="stylesheet" type="text/css" href="style.css" />
	<title>Toko Pakaian Olahraga</title>
</head>
<body>
	<!-- Ini adalah container -->
	<div id="container">
		<!-- Membuat Header-->
			<header>
				<h1>Toko Pakaian Olahraga</h1>
			</header>
		<!-- Membuat Navigasi-->
			<nav>
				<ul>
					<li class="active"><a href="index.php" title="Home"> Home </a></li>
					
					<li><a href="profil.php" title="profil">Profil</a></li>
					<li><a href="kontak.php" title="profil">Kontak</a></li>
					<li><a href="login.php" title="admin">Admin </a></li>
					
				</ul>
			</nav>