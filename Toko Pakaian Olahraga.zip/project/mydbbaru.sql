-- phpMyAdmin SQL Dump
-- version 3.2.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 31, 2018 at 07:23 
-- Server version: 5.1.41
-- PHP Version: 5.3.1

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `id_barang` int(30) NOT NULL AUTO_INCREMENT,
  `nama_barang` varchar(30) NOT NULL,
  `gambar` varchar(100) NOT NULL,
  `harga_jual` decimal(10,0) NOT NULL,
  `harga_beli` decimal(10,0) NOT NULL,
  `stok` int(4) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `deskripsi` text NOT NULL,
  PRIMARY KEY (`id_barang`),
  KEY `id_kategori` (`id_kategori`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `gambar`, `harga_jual`, `harga_beli`, `stok`, `id_kategori`, `deskripsi`) VALUES
(1, 'adidas black', 'gambar/download (2).jpg', '60000', '50000', 4, 1, 'jersey adidas terbaru\r\nwarna hitam\r\nDAPATKAN HARGA PROMO HANYA 60 RB SAJA !!\r\n'),
(2, 'adidas red', 'gambar/download (3).jpg', '60000', '0', 0, 1, 'jersey adidas terbaru\r\nwarna merah\r\nDAPATKAN HARGA PROMO HANYA 60 RB SAJA !!'),
(4, 'nike yellow', 'gambar/download (4).jpg', '61000', '0', 0, 1, 'jersey nike terbaru\r\nwarna kuning\r\nDAPATKAN HARGA PROMO HANYA 61 RB SAJA !!'),
(5, 'nike blue', 'gambar/download (6).jpg', '61000', '0', 0, 1, ''),
(6, 'nike orange', 'gambar/download (5).jpg', '61000', '0', 0, 1, ''),
(7, 'nike orange black', 'gambar/download (7).jpg', '65000', '0', 0, 1, ''),
(8, 'adidas blue', 'gambar/download.jpg', '60000', '0', 0, 1, ''),
(9, 'nike black long', 'gambar/download (8).jpg', '75000', '0', 0, 2, ''),
(10, 'nike black short', 'gambar/download (9).jpg', '70000', '0', 0, 2, ''),
(11, 'adidas blue long', 'gambar/download (10).jpg', '75000', '0', 0, 2, ''),
(12, 'adidas white', 'gambar/download (12).jpg', '100000', '0', 0, 3, ''),
(13, 'adidas black', 'gambar/download (13).jpg', '100000', '0', 0, 3, ''),
(14, 'nike black', 'gambar/download (11).jpg', '105000', '0', 0, 3, ''),
(15, 'nike pink', 'gambar/images.jpg', '100000', '0', 0, 3, ''),
(16, 'adidas black', 'gambar/download (15).jpg', '150000', '0', 0, 4, ''),
(17, 'nike black', 'gambar/download (16).jpg', '145000', '0', 0, 4, '');

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE IF NOT EXISTS `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` varchar(45) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'baju'),
(2, 'celana'),
(3, 'sepatu'),
(4, 'jaket');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(9) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `password` int(9) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `nama`, `password`) VALUES
(311610464, 'admin', 12345);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
